I've created a tool to collect data from Office 365 last year. I decided to create a new one which should be easier to use, easier to expand including the installation of the different required modules. The tool has been created with PowerShell using a WPF user interface. The data collection is being executed in a runspace which makes the GUI responsive during the collection. This tool is just a start to collect Office 365, Exchange Online and SharePoint Online data with PowerShell where I will expand it based on customer requirements. It is possible to create certain checks to for example only list webs with unique permissions or show lists with more then an x number of items.

Please let me know your which information you would like to collect and I'll add it to the tool.

The information about this tool can be found at https://www.sharepointfire.com/2018/08/collect-office-365-exchange-online-and-sharepoint-online-data-with-powershell/
