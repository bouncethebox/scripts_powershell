# get-o365info
Powershell scripts to retrieve Office365 tenant information

Connect-O365    Connects to a Microsoft Office365 environment

Get-O365-Info   Connects to a Microsoft Office365 environment, and shows tenants (domain/user/license) information
