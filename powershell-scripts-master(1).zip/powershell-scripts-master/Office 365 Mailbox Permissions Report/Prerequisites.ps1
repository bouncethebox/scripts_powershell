﻿Set-ExecutionPolicy RemoteSigned
Install-Module MSOnline
Import-Module Msonline