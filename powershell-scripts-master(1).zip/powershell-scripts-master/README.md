# PowerShell-Scripts
Following are the available Office 365 PowerShell Scripts

    -Office 365 Users' Detailed License Report

    -Office 365 Users' Last Logon Time Report

    -Office 365 Mailbox Permission Report

    -Office 365 Dynamic Distribution Groups' Members Report

    -Office 365 Users' MFA Status Reporting

    -Office 365 Users' Last Activity Time Report

    -Office 365 Distribution Group Members Reporting

    -Connect to Exchange Online PowerShell Script(Works for MFA too)

    -Connect to all Office 365 Services PowerShell Script (Supports MFA)

    -Install all Office 365 PowerShell modules
    
    -Office 365 Users Logon History Report
    
    -Office 365 Shared Mailbox Permission Report
    
    -Office 365 Non-Owner Mailbox Access Report
    
    -Office 365 Password Expiry Report
